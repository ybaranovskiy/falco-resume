import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const openAIApiKey = Deno.env.get('OPENAI_API_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { settings, resume, jobDescription } = await req.json();
    console.log('Received request with settings:', settings);

    let systemPrompt = `You are an expert resume tailoring assistant. Format your response as clean HTML without any markdown code blocks or additional text. Follow these formatting rules:

1. Structure:
- Use <h1> for main sections (e.g., "SUMMARY", "WORK EXPERIENCE", "EDUCATION", "SKILLS")
- Use <h2> for company names
- Use <h3> for job titles with dates
- Use <p> for location and company descriptions
- Use <hr> to separate major sections

2. Text Formatting:
- Use <b> or <strong> for emphasis on company names and important achievements
- Use <i> or <em> for dates and locations
- Never use inline styles or CSS

3. Lists:
- Use <ul> for bullet points listing job responsibilities and achievements
- Use nested <ul> for sub-points when needed
- Each experience should be in bullet point format

4. Content Organization:
- Start with a Summary section
- Follow with Work Experience (most recent first)
- Include Education
- End with Skills
- Keep dates in consistent format

Return only the formatted HTML content without any additional text, markdown delimiters, or explanations.`;

    const userPrompt = `Here is my current resume:
${resume}

Here is the job description I'm applying for:
${jobDescription}

Please rewrite my resume to better match this job description while following the HTML formatting guidelines above. Focus on highlighting relevant experience and skills that align with the job requirements.`;

    console.log('Sending request to OpenAI with system prompt:', systemPrompt);

    if (!openAIApiKey) {
      throw new Error('OpenAI API key is not configured');
    }

    const openAIResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: 0.7,
      }),
    });

    console.log('OpenAI response status:', openAIResponse.status);
    
    if (!openAIResponse.ok) {
      const errorData = await openAIResponse.text();
      console.error('OpenAI API error:', errorData);
      throw new Error(`OpenAI API error: ${errorData}`);
    }

    const data = await openAIResponse.json();
    console.log('OpenAI response data:', data);

    if (!data.choices || !data.choices[0] || !data.choices[0].message) {
      console.error('Invalid OpenAI response structure:', data);
      throw new Error('Invalid response structure from OpenAI');
    }

    const generatedContent = data.choices[0].message.content;

    return new Response(JSON.stringify({ generatedContent }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in generate-prompt function:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});