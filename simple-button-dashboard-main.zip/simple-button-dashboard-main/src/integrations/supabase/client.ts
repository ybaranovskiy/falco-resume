import { createClient } from '@supabase/supabase-js';

// These environment variables are automatically injected by the Lovable platform
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://mnstzvssuakbuirqdaiq.supabase.co";
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1uc3R6dnNzdWFrYnVpcnFkYWlxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzUxODY1ODUsImV4cCI6MjA1MDc2MjU4NX0.LouCwv66MHrJMmP1rAUOAg6VlZIq8lfYrNPnppnX_PM";

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);