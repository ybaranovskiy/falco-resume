export interface Project {
  id: string;
  title: string;
  resume: string;
  job_description: string;
  job_url?: string;
  summary?: string;
  created_at: string;
  tailored_output?: string;
}