import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { ActionButton } from "@/components/ActionButton";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { NewProjectModal } from "@/components/NewProjectModal";
import { ProjectCard } from "@/components/ProjectCard";
import { TailoredContentCard } from "@/components/TailoredContentCard";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { SettingsModal } from "@/components/SettingsModal";
import {
  BarChart3,
  FileText,
  Mail,
  MessageSquare,
  PlusCircle,
  Share2,
  Upload,
  Users,
} from "lucide-react";

const Index = () => {
  const { toast } = useToast();
  const [isNewProjectModalOpen, setIsNewProjectModalOpen] = useState(false);
  const [projectCount, setProjectCount] = useState(1);
  const [selectedProject, setSelectedProject] = useState<any>(null);

  // Add click outside listener
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.project-card') && !target.closest('.tailored-content-card')) {
        setSelectedProject(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const { data: projects, refetch: refetchProjects } = useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("projects")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const handleAction = (action: string) => {
    if (action === "New Project") {
      setIsNewProjectModalOpen(true);
    } else {
      toast({
        title: "Action Triggered",
        description: `You clicked the ${action} button`,
      });
    }
  };

  const handleProjectCreated = async () => {
    setProjectCount((prev) => prev + 1);
    setIsNewProjectModalOpen(false);
    await refetchProjects();
    const newProject = projects?.[0];
    if (newProject) {
      setSelectedProject(newProject);
    }
    toast({
      title: "Success",
      description: "New project created successfully",
    });
  };

  const handleProjectSelect = (project: any) => {
    setSelectedProject(project);
  };

  const handleProjectDelete = () => {
    setSelectedProject(null);
  };

  const actions = [
    { icon: PlusCircle, label: "New Project", action: "New Project" },
    { icon: Upload, label: "Upload Files", action: "Upload Files" },
    { icon: Users, label: "Team Members", action: "Team Members" },
    { icon: MessageSquare, label: "Messages", action: "Messages" },
    { icon: BarChart3, label: "Analytics", action: "Analytics" },
    { icon: FileText, label: "Documents", action: "Documents" },
    { icon: Mail, label: "Email", action: "Email" },
    { icon: Share2, label: "Share", action: "Share" },
  ];

  return (
    <SidebarProvider>
      <div className="flex h-screen w-full overflow-hidden">
        <DashboardSidebar />
        <main className="flex-1 overflow-y-auto">
          <div className="container mx-auto p-6">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold">Resume Tailor</h1>
                <p className="text-muted-foreground mt-1">
                  Customize your resume for each job application
                </p>
              </div>
              <div className="flex items-center gap-2">
                <SettingsModal />
                <SidebarTrigger />
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {actions.slice(0, 4).map((action) => (
                <ActionButton
                  key={action.label}
                  icon={action.icon}
                  label={action.label}
                  onClick={() => handleAction(action.action)}
                />
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <div className="lg:col-span-3">
                <div className="sticky top-8">
                  <h2 className="text-xl font-semibold mb-4">Your Projects</h2>
                  <div className="space-y-4 project-card">
                    {projects?.map((project) => (
                      <ProjectCard 
                        key={project.id} 
                        project={project}
                        onSelect={() => handleProjectSelect(project)}
                        onDelete={handleProjectDelete}
                        isSelected={selectedProject?.id === project.id}
                      />
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="lg:col-span-9">
                {selectedProject ? (
                  <div className="tailored-content-card">
                    <TailoredContentCard project={selectedProject} />
                  </div>
                ) : (
                  <div className="rounded-lg border-2 border-dashed border-muted p-12 text-center">
                    <h3 className="text-lg font-medium text-muted-foreground mb-2">
                      No Project Selected
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Select a project from the list to view and edit its content
                    </p>
                    <Button
                      variant="outline"
                      onClick={() => setIsNewProjectModalOpen(true)}
                    >
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Create New Project
                    </Button>
                  </div>
                )}
              </div>
            </div>

            <NewProjectModal
              open={isNewProjectModalOpen}
              onOpenChange={setIsNewProjectModalOpen}
              onProjectCreated={handleProjectCreated}
              defaultTitle={`Tailored Resume ${projectCount}`}
            />
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
};

export default Index;
