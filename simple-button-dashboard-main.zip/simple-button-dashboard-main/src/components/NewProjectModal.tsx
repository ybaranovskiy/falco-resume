import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ResumeInput } from "./project/ResumeInput";
import { JobDescriptionInput } from "./project/JobDescriptionInput";

interface NewProjectModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onProjectCreated: () => void;
  defaultTitle: string;
}

export const NewProjectModal = ({
  open,
  onOpenChange,
  onProjectCreated,
  defaultTitle,
}: NewProjectModalProps) => {
  const { toast } = useToast();
  const [title, setTitle] = useState(defaultTitle);
  const [resume, setResume] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [jobUrl, setJobUrl] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Reset form when modal opens
  useEffect(() => {
    if (open) {
      setTitle(defaultTitle);
      setResume("");
      setJobDescription("");
      setJobUrl("");
    }
  }, [open, defaultTitle]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resume || !jobDescription) {
      toast({
        title: "Error",
        description: "Please fill in both resume and job description fields",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const { data: project, error: insertError } = await supabase
        .from("projects")
        .insert({
          title,
          resume,
          job_description: jobDescription,
          job_url: jobUrl,
        })
        .select()
        .single();

      if (insertError) throw insertError;

      const { data, error } = await supabase.functions.invoke('generate-prompt', {
        body: {
          resume,
          jobDescription,
          settings: {
            toneEnabled: true,
            tone: 4,
            creativityEnabled: true,
            creativity: 3,
            keywordDensityEnabled: true,
            keywordDensity: 4,
            detailDepthEnabled: true,
            detailDepth: 4,
            industryJargonEnabled: true,
            industryJargon: 3,
            personalization: 4,
            conciseness: 4
          }
        }
      });

      if (error) throw error;

      const { error: updateError } = await supabase
        .from("projects")
        .update({ tailored_output: data.generatedContent })
        .eq("id", project.id);

      if (updateError) throw updateError;

      onProjectCreated();
      onOpenChange(false);
      toast({
        title: "Success",
        description: "Project created and content generated successfully",
      });
    } catch (error) {
      console.error("Error creating project:", error);
      toast({
        title: "Error",
        description: "Failed to create project. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Create New Project</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Title (Optional)</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter project title"
            />
          </div>

          <ResumeInput resume={resume} setResume={setResume} />
          <JobDescriptionInput
            jobDescription={jobDescription}
            setJobDescription={setJobDescription}
            jobUrl={jobUrl}
            setJobUrl={setJobUrl}
          />

          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting} className="min-w-[100px]">
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                  <span>Creating...</span>
                </div>
              ) : (
                "Create Project"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};