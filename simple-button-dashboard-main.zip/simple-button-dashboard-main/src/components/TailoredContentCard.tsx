import { useState } from "react";
import { Card } from "@/components/ui/card";
import { ContentEditor } from "./tailored-content/ContentEditor";
import { FeedbackSection } from "./tailored-content/FeedbackSection";
import { TailoredContentHeader } from "./tailored-content/TailoredContentHeader";
import { supabase } from "@/integrations/supabase/client";
import { Project } from "@/types/project";
import { useToast } from "@/hooks/use-toast";

interface TailoredContentCardProps {
  project: Project;
}

export function TailoredContentCard({ project }: TailoredContentCardProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [tailoredOutput, setTailoredOutput] = useState(project.tailored_output || "");
  const { toast } = useToast();

  const handleGenerate = async () => {
    try {
      setIsGenerating(true);
      console.log("Generating tailored resume with:", {
        resume: project.resume,
        jobDescription: project.job_description
      });

      const { data, error } = await supabase.functions.invoke('generate-prompt', {
        body: {
          resume: project.resume,
          jobDescription: project.job_description,
          settings: {
            toneEnabled: true,
            tone: 4,
            creativityEnabled: true,
            creativity: 3,
            keywordDensityEnabled: true,
            keywordDensity: 4,
            detailDepthEnabled: true,
            detailDepth: 4,
            industryJargonEnabled: true,
            industryJargon: 3,
            personalization: 4,
            conciseness: 4
          }
        }
      });

      if (error) {
        console.error("Error from edge function:", error);
        throw error;
      }

      console.log("Received response from edge function:", data);
      setTailoredOutput(data.generatedContent);
      
      // Update the project in Supabase
      const { error: updateError } = await supabase
        .from("projects")
        .update({ tailored_output: data.generatedContent })
        .eq("id", project.id);

      if (updateError) {
        console.error("Error updating project:", updateError);
        toast({
          title: "Error",
          description: "Failed to save the tailored resume",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error generating tailored resume:", error);
      toast({
        title: "Error",
        description: "Failed to generate tailored resume",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);
      const { error } = await supabase
        .from("projects")
        .update({ tailored_output: tailoredOutput })
        .eq("id", project.id);

      if (error) {
        throw error;
      }

      toast({
        title: "Success",
        description: "Changes saved successfully",
      });
    } catch (error) {
      console.error("Error saving changes:", error);
      toast({
        title: "Error",
        description: "Failed to save changes",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleTailoredOutputChange = (newValue: string) => {
    setTailoredOutput(newValue);
  };

  const handleFeedback = async (feedbackText: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('generate-feedback', {
        body: {
          resume: project.resume,
          jobDescription: project.job_description,
          tailoredOutput,
          feedback: feedbackText,
        }
      });

      if (error) {
        console.error("Error from edge function:", error);
        throw error;
      }

      setTailoredOutput(data.improvedOutput);
      
      // Update the project in Supabase
      const { error: updateError } = await supabase
        .from("projects")
        .update({ tailored_output: data.improvedOutput })
        .eq("id", project.id);

      if (updateError) {
        console.error("Error updating project:", updateError);
        toast({
          title: "Error",
          description: "Failed to save the improved output",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error generating feedback:", error);
      toast({
        title: "Error",
        description: "Failed to generate feedback",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="w-full">
      <TailoredContentHeader
        title={project.title}
        onGenerate={handleGenerate}
        isGenerating={isGenerating}
        isSaving={isSaving}
        showFeedback={showFeedback}
        onFeedbackToggle={() => setShowFeedback(!showFeedback)}
        onSave={handleSave}
      />
      <ContentEditor
        resume={project.resume}
        jobDescription={project.job_description}
        tailoredOutput={tailoredOutput}
        onTailoredOutputChange={handleTailoredOutputChange}
      />
      {showFeedback && (
        <FeedbackSection
          feedback=""
          onFeedbackChange={handleFeedback}
        />
      )}
    </Card>
  );
}