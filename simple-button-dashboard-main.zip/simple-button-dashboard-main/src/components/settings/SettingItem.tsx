import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Setting } from "./types";

interface SettingItemProps {
  setting: Setting;
  value: number;
  enabled?: boolean;
  onToggleChange?: (checked: boolean) => void;
  onSliderChange: (value: number[]) => void;
}

export function SettingItem({
  setting,
  value,
  enabled,
  onToggleChange,
  onSliderChange,
}: SettingItemProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <Label>{setting.label}</Label>
          {setting.description && (
            <p className="text-sm text-muted-foreground">{setting.description}</p>
          )}
        </div>
        {setting.hasToggle && onToggleChange && (
          <Switch checked={enabled} onCheckedChange={onToggleChange} />
        )}
      </div>

      {setting.hasSlider && (
        <div className="space-y-2">
          <Slider
            min={1}
            max={5}
            step={1}
            value={[value]}
            onValueChange={onSliderChange}
            disabled={setting.hasToggle && !enabled}
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Subtle</span>
            <span>Light</span>
            <span>Balanced</span>
            <span>Strong</span>
            <span>Maximum</span>
          </div>
        </div>
      )}
    </div>
  );
}