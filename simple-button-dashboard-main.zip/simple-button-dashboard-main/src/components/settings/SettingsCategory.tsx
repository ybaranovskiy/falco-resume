import { Separator } from "@/components/ui/separator";
import { SettingItem } from "./SettingItem";
import { SettingCategory } from "./types";

interface SettingsCategoryProps {
  category: SettingCategory;
  settings: Record<string, any>;
  onToggleChange: (settingId: string, checked: boolean) => void;
  onSliderChange: (settingId: string, value: number[]) => void;
}

export function SettingsCategory({
  category,
  settings,
  onToggleChange,
  onSliderChange,
}: SettingsCategoryProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">{category.name}</h3>
      <Separator />
      {category.settings.map((setting) => (
        <SettingItem
          key={setting.id}
          setting={setting}
          value={settings[setting.id]}
          enabled={settings[`${setting.id}Enabled`]}
          onToggleChange={
            setting.hasToggle
              ? (checked) => onToggleChange(setting.id, checked)
              : undefined
          }
          onSliderChange={(value) => onSliderChange(setting.id, value)}
        />
      ))}
    </div>
  );
}