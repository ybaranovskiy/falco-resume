import { Separator } from "@/components/ui/separator";

interface SettingsPreviewProps {
  previewText: string;
}

export function SettingsPreview({ previewText }: SettingsPreviewProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Preview</h3>
      <Separator />
      <div className="bg-muted p-4 rounded-md">
        <p className="text-sm">{previewText}</p>
      </div>
    </div>
  );
}