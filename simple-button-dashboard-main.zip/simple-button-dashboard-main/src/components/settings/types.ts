export interface SettingCategory {
  name: string;
  settings: Setting[];
}

export interface Setting {
  id: string;
  label: string;
  hasToggle?: boolean;
  hasSlider: boolean;
  description?: string;
}

export const defaultSettings = {
  tone: 3,
  keywordDensityEnabled: true,
  keywordDensity: 3,
  detailDepth: 3,
  creativityEnabled: true,
  creativity: 3,
  industryJargonEnabled: true,
  industryJargon: 3,
  personalization: 3,
  conciseness: 3,
};

export const categories: SettingCategory[] = [
  {
    name: "Tone and Language",
    settings: [
      {
        id: "tone",
        label: "Professional Tone",
        hasSlider: true,
        description: "Adjust the formality level of your resume",
      },
      {
        id: "creativity",
        label: "Creativity",
        hasToggle: true,
        hasSlider: true,
        description: "Include unique, attention-grabbing phrasing",
      },
    ],
  },
  {
    name: "Content Optimization",
    settings: [
      {
        id: "keywordDensity",
        label: "Keyword Density",
        hasToggle: true,
        hasSlider: true,
        description: "Control the frequency of job-related keywords",
      },
      {
        id: "detailDepth",
        label: "Detail Depth",
        hasSlider: true,
        description: "Adjust the level of specificity in bullet points",
      },
    ],
  },
  {
    name: "Industry and Personalization",
    settings: [
      {
        id: "industryJargon",
        label: "Industry Jargon",
        hasToggle: true,
        hasSlider: true,
        description: "Include technical terms and industry-specific language",
      },
      {
        id: "personalization",
        label: "Personalization",
        hasSlider: true,
        description: "Customize the degree of personal touches",
      },
      {
        id: "conciseness",
        label: "Conciseness",
        hasSlider: true,
        description: "Adjust the length and detail of content",
      },
    ],
  },
];