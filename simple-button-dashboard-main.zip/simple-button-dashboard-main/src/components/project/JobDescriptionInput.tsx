import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Upload } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface JobDescriptionInputProps {
  jobDescription: string;
  setJobDescription: (description: string) => void;
  jobUrl: string;
  setJobUrl: (url: string) => void;
}

export const JobDescriptionInput = ({
  jobDescription,
  setJobDescription,
  jobUrl,
  setJobUrl,
}: JobDescriptionInputProps) => {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleJobUrlSubmit = async () => {
    if (!jobUrl) return;

    setIsProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('extract-job', {
        body: { url: jobUrl },
      });

      if (error) throw error;
      setJobDescription(data.description);
      
      toast({
        title: "Success",
        description: "Job description extracted successfully",
      });
    } catch (error) {
      console.error('Error extracting job description:', error);
      toast({
        title: "Error",
        description: "Failed to extract job description. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-2">
      <Label htmlFor="jobDescription">Job Description</Label>
      <div className="flex gap-2 mb-2">
        <Input
          value={jobUrl}
          onChange={(e) => setJobUrl(e.target.value)}
          placeholder="Enter job posting URL"
        />
        <Button
          type="button"
          variant="outline"
          onClick={handleJobUrlSubmit}
          disabled={isProcessing}
        >
          {isProcessing ? (
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
          ) : (
            <Upload className="h-4 w-4" />
          )}
        </Button>
      </div>
      <Textarea
        id="jobDescription"
        value={jobDescription}
        onChange={(e) => setJobDescription(e.target.value)}
        placeholder="Paste job description or enter URL above"
        className="min-h-[200px]"
      />
    </div>
  );
};