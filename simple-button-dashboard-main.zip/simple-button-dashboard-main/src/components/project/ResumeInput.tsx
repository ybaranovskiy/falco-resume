import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Upload } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ResumeInputProps {
  resume: string;
  setResume: (resume: string) => void;
}

export const ResumeInput = ({ resume, setResume }: ResumeInputProps) => {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const { data, error } = await supabase.functions.invoke('parse-pdf', {
        body: formData,
      });

      if (error) throw error;
      
      // Store the file and extracted text
      const fileExt = file.name.split('.').pop();
      const filePath = `${crypto.randomUUID()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('files')
        .upload(filePath, file);
        
      if (uploadError) throw uploadError;

      const { error: dbError } = await supabase
        .from('files')
        .insert({
          filename: file.name,
          file_path: filePath,
          content_type: file.type,
          size: file.size,
          extracted_text: data.text
        });

      if (dbError) throw dbError;
      
      setResume(data.text);
      
      toast({
        title: "Success",
        description: "Resume parsed and stored successfully",
      });
    } catch (error) {
      console.error('Error processing PDF:', error);
      toast({
        title: "Error",
        description: "Failed to process PDF. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-2">
      <Label htmlFor="resume">Existing Resume</Label>
      <div className="flex items-center gap-2 mb-2">
        <div className="relative flex-1">
          <label className="block">
            <div className="relative">
              <Input
                type="file"
                accept=".pdf"
                onChange={handleFileUpload}
                className="sr-only"
                id="resume-upload"
              />
              <Button
                variant="outline"
                className="w-full flex items-center justify-center gap-2"
                asChild
              >
                <label htmlFor="resume-upload" className="cursor-pointer">
                  <Upload className="h-4 w-4" />
                  Choose File
                </label>
              </Button>
            </div>
          </label>
        </div>
        {isProcessing && (
          <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
        )}
      </div>
      <Textarea
        id="resume"
        value={resume}
        onChange={(e) => setResume(e.target.value)}
        placeholder="Upload a PDF or paste your resume here"
        className="min-h-[200px]"
      />
    </div>
  );
};