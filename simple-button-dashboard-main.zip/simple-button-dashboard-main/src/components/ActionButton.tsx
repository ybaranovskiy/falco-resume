import { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ActionButtonProps {
  icon: LucideIcon;
  label: string;
  onClick: () => void;
  className?: string;
}

export function ActionButton({ icon: Icon, label, onClick, className }: ActionButtonProps) {
  return (
    <Button
      variant="outline"
      className={cn(
        "flex flex-col items-center justify-center gap-2 h-32 w-full hover:bg-primary hover:text-primary-foreground transition-all",
        className
      )}
      onClick={onClick}
    >
      <Icon className="h-8 w-8" />
      <span className="text-sm font-medium">{label}</span>
    </Button>
  );
}