import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";

interface ContentEditorProps {
  resume: string;
  jobDescription: string;
  tailoredOutput: string;
  onTailoredOutputChange: (value: string) => void;
}

export function ContentEditor({
  resume,
  jobDescription,
  tailoredOutput,
  onTailoredOutputChange,
}: ContentEditorProps) {
  // Function to strip HTML tags and decode entities
  const stripHtml = (html: string) => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    return doc.body.textContent || "";
  };

  return (
    <div className="p-8 space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-lg font-semibold mb-4">Original Resume</h2>
          <ScrollArea className="h-[300px] w-full rounded-md border bg-background">
            <div className="p-4">
              <Textarea
                value={resume}
                className="min-h-[280px] resize-none border-0 focus-visible:ring-0"
                readOnly
              />
            </div>
          </ScrollArea>
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-4">Job Description</h2>
          <ScrollArea className="h-[300px] w-full rounded-md border bg-background">
            <div className="p-4">
              <Textarea
                value={jobDescription}
                className="min-h-[280px] resize-none border-0 focus-visible:ring-0"
                readOnly
              />
            </div>
          </ScrollArea>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold mb-4">Tailored Resume</h2>
        <div className="w-full rounded-md border bg-background p-4">
          <Textarea
            value={stripHtml(tailoredOutput)}
            onChange={(e) => onTailoredOutputChange(e.target.value)}
            placeholder="Your tailored resume will appear here after generation..."
            className="min-h-[400px] w-full resize-none border-0 focus-visible:ring-0 p-0 leading-relaxed"
          />
        </div>
      </div>
    </div>
  );
}