import { Button } from "@/components/ui/button";
import { Loader2, MessageSquare, Save, Wand2 } from "lucide-react";

interface TailoredContentHeaderProps {
  title: string;
  isGenerating: boolean;
  isSaving: boolean;
  showFeedback: boolean;
  onFeedbackToggle: () => void;
  onGenerate: () => void;
  onSave: () => void;
}

export function TailoredContentHeader({
  title,
  isGenerating,
  isSaving,
  showFeedback,
  onFeedbackToggle,
  onGenerate,
  onSave,
}: TailoredContentHeaderProps) {
  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-8">
      <div>
        <h3 className="text-2xl font-semibold">{title}</h3>
        <p className="text-sm text-muted-foreground mt-2">
          Edit and generate tailored content for your application
        </p>
      </div>
      <div className="flex items-center gap-3">
        <Button
          variant={showFeedback ? "secondary" : "outline"}
          onClick={onFeedbackToggle}
          size="sm"
          className="gap-2"
        >
          <MessageSquare className="h-4 w-4" />
          Feedback
        </Button>
        <Button
          variant="outline"
          onClick={onGenerate}
          disabled={isGenerating}
          size="sm"
          className="gap-2"
        >
          {isGenerating ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Wand2 className="h-4 w-4" />
          )}
          {isGenerating ? "Generating..." : "Generate"}
        </Button>
        <Button 
          onClick={onSave} 
          disabled={isSaving}
          size="sm"
          className="gap-2"
        >
          {isSaving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Save className="h-4 w-4" />
          )}
          {isSaving ? "Saving..." : "Save"}
        </Button>
      </div>
    </div>
  );
}