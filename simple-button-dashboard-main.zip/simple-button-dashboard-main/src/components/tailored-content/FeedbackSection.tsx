import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, Pencil, Brain, Target, Briefcase } from "lucide-react";
import { useEffect, useRef } from "react";

interface FeedbackSectionProps {
  feedback: string;
  onFeedbackChange: (value: string) => void;
}

export function FeedbackSection({ feedback, onFeedbackChange }: FeedbackSectionProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.scrollIntoView({ behavior: 'smooth' });
      textareaRef.current.focus();
    }
  }, []);

  return (
    <Card className="mb-6 mx-8 border-2">
      <CardContent className="p-6">
        <label className="block text-sm font-medium mb-4">
          How would you like to improve the generated content?
        </label>
        <div className="space-y-6">
          <Textarea
            ref={textareaRef}
            value={feedback}
            onChange={(e) => onFeedbackChange(e.target.value)}
            placeholder="E.g., Make it more professional, focus more on leadership skills, etc."
            className="min-h-[100px] w-full"
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onFeedbackChange(feedback + " Make it more professional and formal.")}
              className="w-full text-sm"
            >
              <Briefcase className="h-4 w-4 mr-2" />
              More Professional
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onFeedbackChange(feedback + " Make it more concise and impactful.")}
              className="w-full text-sm"
            >
              <Target className="h-4 w-4 mr-2" />
              More Concise
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onFeedbackChange(feedback + " Add more technical details and skills.")}
              className="w-full text-sm"
            >
              <Brain className="h-4 w-4 mr-2" />
              More Technical
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onFeedbackChange(feedback + " Highlight leadership and management skills.")}
              className="w-full text-sm"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Leadership Focus
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onFeedbackChange(feedback + " Improve the writing style and clarity.")}
              className="w-full text-sm"
            >
              <Pencil className="h-4 w-4 mr-2" />
              Better Writing
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}