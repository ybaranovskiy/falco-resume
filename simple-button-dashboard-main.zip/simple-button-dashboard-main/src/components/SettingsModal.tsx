import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Settings, Save, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { categories, defaultSettings } from "./settings/types";
import { SettingsCategory } from "./settings/SettingsCategory";
import { SettingsPreview } from "./settings/SettingsPreview";

const previewText = {
  base: "Led cross-functional team initiatives",
  keywords: "and improved operational efficiency",
  technical: "utilizing Agile methodologies",
  personal: "while mentoring junior team members",
};

export function SettingsModal() {
  const [settings, setSettings] = useState(defaultSettings);
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);

  const handleToggleChange = (settingId: string, checked: boolean) => {
    setSettings((prev) => ({
      ...prev,
      [`${settingId}Enabled`]: checked,
    }));
  };

  const handleSliderChange = (settingId: string, value: number[]) => {
    setSettings((prev) => ({
      ...prev,
      [settingId]: value[0],
    }));
  };

  const resetSettings = () => {
    setSettings(defaultSettings);
    toast({
      title: "Settings Reset",
      description: "All settings have been restored to their default values.",
    });
  };

  const saveDefaults = () => {
    localStorage.setItem("resumeSettings", JSON.stringify(settings));
    toast({
      title: "Settings Saved",
      description: "Your preferences have been saved as the default settings.",
    });
  };

  const generatePreviewText = () => {
    let preview = previewText.base;
    
    if (settings.keywordDensityEnabled && settings.keywordDensity > 2) {
      preview += " " + previewText.keywords;
    }
    
    if (settings.industryJargonEnabled && settings.industryJargon > 2) {
      preview += " " + previewText.technical;
    }
    
    if (settings.personalization > 3) {
      preview += " " + previewText.personal;
    }
    
    return preview;
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <Button
        variant="ghost"
        onClick={() => setIsOpen(true)}
        className="w-full justify-start gap-2"
      >
        <Settings className="h-5 w-5" />
        <span>Settings</span>
      </Button>
      <DialogContent className="sm:max-w-[600px] h-[80vh]">
        <DialogHeader>
          <DialogTitle>Resume Settings</DialogTitle>
          <DialogDescription>
            Customize how your resume content is generated and formatted.
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 px-1">
          <div className="py-6 space-y-8 pr-4">
            {categories.map((category) => (
              <SettingsCategory
                key={category.name}
                category={category}
                settings={settings}
                onToggleChange={handleToggleChange}
                onSliderChange={handleSliderChange}
              />
            ))}

            <SettingsPreview previewText={generatePreviewText()} />
          </div>
        </ScrollArea>

        <DialogFooter className="flex-col sm:flex-row gap-2">
          <div className="flex gap-2 w-full sm:w-auto">
            <Button
              variant="outline"
              onClick={resetSettings}
              className="flex-1 sm:flex-none"
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              Reset
            </Button>
            <Button
              variant="outline"
              onClick={saveDefaults}
              className="flex-1 sm:flex-none"
            >
              <Save className="mr-2 h-4 w-4" />
              Save Defaults
            </Button>
          </div>
          <Button onClick={() => setIsOpen(false)}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}