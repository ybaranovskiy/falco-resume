import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface Project {
  id: string;
  title: string;
  resume: string;
  job_description: string;
  job_url?: string;
  summary?: string;
}

interface ProjectDetailsModalProps {
  project: Project;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ProjectDetailsModal({
  project,
  open,
  onOpenChange,
}: ProjectDetailsModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{project.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="space-y-2">
            <Label>Resume</Label>
            <Textarea
              value={project.resume}
              className="min-h-[200px]"
              readOnly
            />
          </div>

          <div className="space-y-2">
            <Label>Job Description</Label>
            <Textarea
              value={project.job_description}
              className="min-h-[200px]"
              readOnly
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}