import { Home, LayoutDashboard, Settings, Users, ChevronLeft, ChevronRight } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuItem,
} from "@/components/ui/sidebar";
import { SettingsModal } from "./SettingsModal";
import { useState } from "react";
import { Button } from "./ui/button";

const menuItems = [
  {
    title: "Home",
    icon: Home,
    url: "#",
  },
  {
    title: "Dashboard",
    icon: LayoutDashboard,
    url: "#",
  },
  {
    title: "Users",
    icon: Users,
    url: "#",
  },
];

export function DashboardSidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <Sidebar className={`fixed top-0 left-0 h-full transition-all duration-300 ${isCollapsed ? 'w-16' : 'w-64'}`}>
      <SidebarContent>
        <SidebarGroup>
          <div className="flex items-center justify-between px-4 py-2">
            <SidebarGroupLabel className={isCollapsed ? 'hidden' : ''}>Menu</SidebarGroupLabel>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsCollapsed(!isCollapsed)}
              className="ml-auto"
            >
              {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
            </Button>
          </div>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <Button
                    variant="ghost"
                    className="w-full justify-start gap-4 px-4"
                    asChild
                  >
                    <a href={item.url}>
                      <item.icon className="h-5 w-5" />
                      <span className={isCollapsed ? 'hidden' : ''}>
                        {item.title}
                      </span>
                    </a>
                  </Button>
                </SidebarMenuItem>
              ))}
              <SidebarMenuItem>
                <SettingsModal />
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}